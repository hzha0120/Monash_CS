from django.contrib import admin
from .models import EWasteSite, Clothing
# Register your models here.

admin.site.register(EWasteSite)
admin.site.register(Clothing)